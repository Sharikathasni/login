import "./footer.css"

export const Footer = () => {
    return <div className="footer-container">
        <div className="right"><b>Fashion Company</b></div>
        <div className="left">Link</div>
        <div className="left">Help</div>
        <div className="left">Newsletter</div>
    </div>
}

